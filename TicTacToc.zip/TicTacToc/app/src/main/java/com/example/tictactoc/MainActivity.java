package com.example.tictactoc;


import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    int scoreX = 0;
    int scoreO = 0;

    TextView tvScoreX;
    TextView tvScoreO;





    Button[] buttons = new Button[9];
    String currentPlayer = "X";
    boolean gameActive = true;
    TextView tvStatus;

    int[][] winPositions = {
            {0,1,2}, {3,4,5}, {6,7,8}, // rows
            {0,3,6}, {1,4,7}, {2,5,8}, // columns
            {0,4,8}, {2,4,6}           // diagonals
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvStatus = findViewById(R.id.tvStatus);
        Button btnReset = findViewById(R.id.btnReset);


        tvScoreX = findViewById(R.id.tvScoreX);
        tvScoreO = findViewById(R.id.tvScoreO);
        Button btnResetScores = findViewById(R.id.btnResetScores);
        btnResetScores.setOnClickListener(v -> {
            scoreX = 0;
            scoreO = 0;
            tvScoreX.setText("X: 0");
            tvScoreO.setText("O: 0");
            Toast.makeText(this, "Scores reset!", Toast.LENGTH_SHORT).show();
        });


        Button myButton0 = findViewById(R.id.btn0);
        myButton0.setBackgroundColor(Color.parseColor("#6991E4"));

        Button myButton1 = findViewById(R.id.btn1);
        myButton1.setBackgroundColor(Color.parseColor("#6991E4"));

        Button myButton2 = findViewById(R.id.btn2);
        myButton2.setBackgroundColor(Color.parseColor("#6991E4"));

        Button myButton3 = findViewById(R.id.btn3);
        myButton3.setBackgroundColor(Color.parseColor("#6991E4"));

        Button myButton4 = findViewById(R.id.btn4);
        myButton4.setBackgroundColor(Color.parseColor("#6991E4"));

        Button myButton5 = findViewById(R.id.btn5);
        myButton5.setBackgroundColor(Color.parseColor("#6991E4"));

        Button myButton6 = findViewById(R.id.btn6);
        myButton6.setBackgroundColor(Color.parseColor("#6991E4"));

        Button myButton7 = findViewById(R.id.btn7);
        myButton7.setBackgroundColor(Color.parseColor("#6991E4"));

        Button myButton8 = findViewById(R.id.btn8);
        myButton8.setBackgroundColor(Color.parseColor("#6991E4"));


        // Initialize buttons
        for (int i = 0; i < 9; i++) {
            String btnID = "btn" + i;
            int resID = getResources().getIdentifier(btnID, "id", getPackageName());
            buttons[i] = findViewById(resID);

            final int index = i;
            buttons[i].setOnClickListener(v -> handleMove(index));
        }

        btnReset.setOnClickListener(v -> resetGame());
    }

    private void handleMove(int index) {
        if (!gameActive || !buttons[index].getText().toString().equals("")) return;

        buttons[index].setText(currentPlayer);

        if (checkWinner()) {

            tvStatus.setText("Player " + currentPlayer + " wins!");
            if (currentPlayer.equals("X")) {
                scoreX++;
                tvScoreX.setText("X: " + scoreX);
            } else {
                scoreO++;
                tvScoreO.setText("O: " + scoreO);
            }
            gameActive = false;






        } else if (isDraw()) {
            tvStatus.setText("It's a draw!");
            gameActive = false;
        } else {
            currentPlayer = currentPlayer.equals("X") ? "O" : "X";
            tvStatus.setText("Player " + currentPlayer + "'s Turn");
        }
    }

    private boolean checkWinner() {
        for (int[] pos : winPositions) {
            String a = buttons[pos[0]].getText().toString();
            String b = buttons[pos[1]].getText().toString();
            String c = buttons[pos[2]].getText().toString();
            if (!a.equals("") && a.equals(b) && b.equals(c)) {
                highlightWinner(pos);
                return true;
            }
        }
        return false;
    }

    private boolean isDraw() {
        for (Button btn : buttons) {
            if (btn.getText().toString().equals("")) return false;
        }
        return true;
    }

    private void highlightWinner(int[] pos) {
        for (int index : pos) {
            buttons[index].setBackgroundColor(getResources().getColor(android.R.color.holo_red_light));
        }
    }

    private void resetGame() {
        currentPlayer = "X";
        gameActive = true;
        tvStatus.setText("Player X's Turn");

            for (int i = 0; i < 9; i++) {
                Button button = findViewById(getResources().getIdentifier("btn" + i, "id", getPackageName()));
                button.setText(""); // Clear the text
                button.setBackgroundColor(getResources().getColor(android.R.color.system_palette_key_color_neutral_dark));

        }
    }

}
